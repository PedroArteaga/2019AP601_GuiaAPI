﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using _2019AP601_GuiaAPI.Models;
using Microsoft.EntityFrameworkCore;
using _2019AP601_GuiaAPI;

namespace _2019MS604.Controllers
{

    [ApiController]
    public class estados_equipocontroller : ControllerBase
    {
        private readonly estados_equipoContext _contexto;
        public estados_equipocontroller(estados_equipoContext miContexto)
        {
            this._contexto = miContexto;
        }
        [HttpGet]
        [Route("api/estados_equipo")]
        public IActionResult Get()
        {
            IEnumerable<estados_equipo> estadoequipoList = from e in _contexto.estados_equipo
                                                           select e;
            if (estadoequipoList.Count() > 0)
            {
                return Ok(estadoequipoList);
            }
            return NotFound();

        }
        [HttpGet]
        [Route("api/estados_equipo/{id}")]
        public IActionResult getbyId(int id)
        {
            estados_equipo unEstado = (from e in _contexto.estados_equipo
                                       where e.id_estados_equipo == id
                                       select e).FirstOrDefault();
            if (unEstado != null)
            {
                return Ok(unEstado);
            }
            return NotFound();
        }

        [HttpPost]
        [Route("api/estados_equipo")]
        public IActionResult guardarEstado([FromBody] estados_equipo estadoNuevo)
        {
            try
            {
                IEnumerable<estados_equipo> estadoExiste = from e in _contexto.estados_equipo
                                                           where e.estado == estadoNuevo.estado
                                                           select e;
                if (estadoExiste.Count() == 0)
                {
                    _contexto.estados_equipo.Add(estadoNuevo);
                    _contexto.SaveChanges();
                    return Ok(estadoNuevo);
                }
                return Ok(estadoExiste);
            }
            catch (System.Exception)
            {
                return BadRequest();

            }
        }

        [HttpPut]
        [Route("api/estados_equipo")]
        public IActionResult updateEstado([FromBody] estados_equipo estadoAModificar)
        {
            estados_equipo estadoExiste = (from e in _contexto.estados_equipo
                                           where e.id_estados_equipo == estadoAModificar.id_estados_equipo
                                           select e).FirstOrDefault();
            if (estadoExiste is null)
            {
                return NotFound();
            }
            estadoExiste.descripcion = estadoAModificar.descripcion;
            estadoExiste.estado = estadoAModificar.estado;

            _contexto.Entry(estadoExiste).State = EntityState.Modified;
            _contexto.SaveChanges();
            return Ok(estadoExiste);
        }
    }
}