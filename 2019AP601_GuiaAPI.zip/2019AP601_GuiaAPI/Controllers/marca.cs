﻿namespace _2019AP601_GuiaAPI.Controllers
{
    internal class marca
    {
        internal string nombre_marca;
    }
}