﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using _2019AP601_GuiaAPI.Models;

namespace _2019AP601_GuiaAPI
{
    public class equiposContext : DbContext
    {
        public equiposContext(DbContextOptions<equiposContext> options) : base(options)
        {

        }
        public DbSet<equipos> equipos { get; set; }

        public static implicit operator equiposContext(estados_equipoContext v)
        {
            throw new NotImplementedException();
        }
    }
}
