﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _2019AP601_GuiaAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace _2019AP601_GuiaAPI
{
    public class tipo_equipoContext : DbContext
    {
        public tipo_equipoContext(DbContextOptions<tipo_equipoContext> options) : base(options)
        {

        }
        public DbSet<tipo_equipo> tipo_equipo { get; set; }
    }
}
