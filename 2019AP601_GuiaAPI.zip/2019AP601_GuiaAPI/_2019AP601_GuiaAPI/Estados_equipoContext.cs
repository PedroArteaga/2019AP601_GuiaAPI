﻿namespace _2019AP601_GuiaAPI
{
    internal class Estados_equipoContext
    {
    }
}